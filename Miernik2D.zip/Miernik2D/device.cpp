#include "device.h"

device::device(){}
