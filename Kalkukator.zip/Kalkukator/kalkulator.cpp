#include "kalkulator.h"

Kalkulator::Kalkulator() {}
