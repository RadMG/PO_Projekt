#ifndef KALKULATOR_H
#define KALKULATOR_H

class Kalkulator
{
public:
    Kalkulator();
};

#endif // KALKULATOR_H
